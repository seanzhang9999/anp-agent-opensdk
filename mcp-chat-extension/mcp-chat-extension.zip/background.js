// 导入MCP客户端
importScripts('mcp-client.js');

let mcpClient = null;
let connectionStatus = 'disconnected';

/**
 * 初始化MCP客户端
 */
async function initializeMCP(config = {}) {
  try {
    const defaultConfig = {
      serverUrl: 'http://localhost:8000',
      didProviderUrl: 'http://localhost:9511'
    };
    
    const mcpConfig = { ...defaultConfig, ...config };
    
    mcpClient = new MCPClient(mcpConfig);
    await mcpClient.initialize();
    
    connectionStatus = 'connected';
    broadcastMessage({ type: 'mcp.connected', config: mcpConfig });
    
    console.log('MCP客户端初始化成功');
    return true;
  } catch (error) {
    connectionStatus = 'error';
    broadcastMessage({ type: 'mcp.error', error: error.message });
    console.error('MCP客户端初始化失败:', error);
    return false;
  }
}

/**
 * 广播消息给popup
 */
function broadcastMessage(message) {
  chrome.storage.local.set({ 
    lastMessage: { ...message, timestamp: Date.now() } 
  });
}

/**
 * 处理来自popup的消息
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Background received:', message);

  switch (message.type) {
    case 'mcp.init':
      handleMCPInit(message, sendResponse);
      return true;

    case 'mcp.rpc':
      handleMCPRPC(message, sendResponse);
      return true;

    case 'mcp.status':
      sendResponse({ 
        status: connectionStatus, 
        hasClient: !!mcpClient,
        isInitialized: mcpClient?.isInitialized || false
      });
      break;

    default:
      sendResponse({ error: 'Unknown message type' });
  }
});

/**
 * 处理MCP初始化
 */
async function handleMCPInit(message, sendResponse) {
  try {
    const success = await initializeMCP(message.config);
    sendResponse({ success, status: connectionStatus });
  } catch (error) {
    sendResponse({ success: false, error: error.message });
  }
}

/**
 * 处理MCP RPC调用
 */
async function handleMCPRPC(message, sendResponse) {
  try {
    if (!mcpClient || !mcpClient.isInitialized) {
      throw new Error('MCP client not initialized');
    }

    let result;
    switch (message.method) {
      case 'tools/list':
        result = await mcpClient.listTools();
        break;
      case 'tools/call':
        result = await mcpClient.callTool(message.params.name, message.params.arguments);
        break;
      default:
        result = await mcpClient.rpc(message.method, message.params);
    }

    sendResponse({ success: true, data: result });
  } catch (error) {
    console.error('MCP RPC error:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// 扩展安装时初始化
chrome.runtime.onInstalled.addListener(() => {
  console.log('MCP Chat Extension installed');
});