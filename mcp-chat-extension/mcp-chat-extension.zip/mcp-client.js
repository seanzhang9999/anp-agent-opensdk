/**
 * MCP客户端 - 基于demo_mcp_anp_did_auth.py中的MCPClientWithDID类
 * 支持DID认证的MCP (Model Context Protocol) 客户端
 */
class MCPClient {
  constructor(options = {}) {
    this.serverUrl = options.serverUrl || 'http://localhost:8000';
    this.didProviderUrl = options.didProviderUrl || 'http://localhost:9511';
    this.timeout = options.timeout || 30000;
    this._did = null;
    this.isInitialized = false;
  }

  /**
   * 初始化客户端 - 对应Python版本的initialize方法
   */
  async initialize() {
    try {
      // 从DID Provider获取DID
      this._did = await this.getDIDFromProvider();
      this.isInitialized = true;
      console.log(`MCP Client初始化完成，DID: ${this._did}`);
      return true;
    } catch (error) {
      console.error('MCP Client初始化失败:', error);
      throw error;
    }
  }

  /**
   * 从DID Provider获取DID
   */
  async getDIDFromProvider() {
    const response = await fetch(`${this.didProviderUrl}/did`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      throw new Error(`Failed to get DID: ${response.status}`);
    }

    const data = await response.json();
    return data.did;
  }

  /**
   * 生成DID签名
   */
  async signPayload(payload) {
    const response = await fetch(`${this.didProviderUrl}/sign`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ payload })
    });

    if (!response.ok) {
      throw new Error(`Failed to sign payload: ${response.status}`);
    }

    const data = await response.json();
    return data.jws;
  }

  /**
   * 发送RPC请求 - 对应Python版本的rpc方法
   */
  async rpc(method, params = {}) {
    if (!this.isInitialized) {
      throw new Error('MCP Client not initialized');
    }

    // 1. 构建请求数据 - 与Python版本相同的结构
    const timestamp = Math.floor(Date.now() / 1000);
    const requestData = {
      jsonrpc: '2.0',
      method: method,
      params: params,
      id: `req_${timestamp}`,
      __meta: {
        ts: timestamp
      }
    };

    // 2. 生成认证签名
    const payloadData = {
      method: method,
      params: params,
      timestamp: timestamp
    };
    const payload = JSON.stringify(payloadData, Object.keys(payloadData).sort());
    const signature = await this.signPayload(payload);

    // 3. 构建认证头
    const authToken = JSON.stringify({
      did: this._did,
      signature: signature
    });

    // 4. 发送请求
    const response = await fetch(`${this.serverUrl}/mcp/rpc`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestData)
    });

    if (!response.ok) {
      throw new Error(`MCP RPC调用失败: ${response.status}`);
    }

    return await response.json();
  }

  /**
   * 调用工具 - 对应Python版本的call_tool方法
   */
  async callTool(toolName, arguments = {}) {
    return await this.rpc('tools/call', {
      name: toolName,
      arguments: arguments
    });
  }

  /**
   * 列出可用工具 - 对应Python版本的list_tools方法
   */
  async listTools() {
    return await this.rpc('tools/list', {});
  }

  /**
   * 获取MCP服务能力
   */
  async getCapabilities() {
    const response = await fetch(`${this.serverUrl}/mcp/capabilities`);
    if (!response.ok) {
      throw new Error(`Failed to get capabilities: ${response.status}`);
    }
    return await response.json();
  }

  /**
   * 检查连接状态
   */
  async checkConnection() {
    try {
      await this.getCapabilities();
      return true;
    } catch (error) {
      return false;
    }
  }
}

// 导出类
if (typeof module !== 'undefined' && module.exports) {
  module.exports = MCPClient;
} else {
  window.MCPClient = MCPClient;
}